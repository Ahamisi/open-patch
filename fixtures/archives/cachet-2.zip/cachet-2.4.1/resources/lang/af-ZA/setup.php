<?php

/*
 * This file is part of Cachet.
 *
 * (c) Alt Three Services Limited
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

return [
    'setup'             => 'Setup',
    'title'             => 'Install Cachet',
    'service_details'   => 'Service Details',
    'env_setup'         => 'Environment Setup',
    'status_page_setup' => 'Status Page Setup',
    'show_support'      => 'Show support for Cachet?',
    'admin_account'     => 'Administrator Account',
    'complete_setup'    => 'Complete Setup',
    'completed'         => 'Cachet has been configured successfully!',
    'finish_setup'      => 'Go to dashboard',
];
