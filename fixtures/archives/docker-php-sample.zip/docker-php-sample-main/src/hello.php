<?php
     echo "Hello, world!";
   ?>